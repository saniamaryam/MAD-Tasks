import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { evaluate } from 'mathjs';

export default function App() {
  const [input, setInput] = useState('');

  const handlePress = (value) => {
    if (value === '=') {
      try {
        setInput(evaluate(input).toString());
      } catch (error) {
        setInput('Error');
      }
    } else if (value === 'C') {
      setInput('');
    } else if (value === '⌫') {
      setInput(input.slice(0, -1));
    } else {
      setInput(input + value);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.display}>{input || '0'}</Text>

      {/* Scientific Functions */}
      <View style={styles.row}>
        {['sin(', 'cos(', 'tan(', 'log('].map((item) => (
          <TouchableOpacity key={item} style={styles.funcButton} onPress={() => handlePress(item)}>
            <Text style={styles.funcText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.row}>
        {['√(', '^', 'π', 'e'].map((item) => (
          <TouchableOpacity key={item} style={styles.funcButton} onPress={() => handlePress(item)}>
            <Text style={styles.funcText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Number Pad */}
      <View style={styles.row}>
        {['7', '8', '9', '/'].map((item) => (
          <TouchableOpacity key={item} style={styles.button} onPress={() => handlePress(item)}>
            <Text style={styles.buttonText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.row}>
        {['4', '5', '6', '*'].map((item) => (
          <TouchableOpacity key={item} style={styles.button} onPress={() => handlePress(item)}>
            <Text style={styles.buttonText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.row}>
        {['1', '2', '3', '-'].map((item) => (
          <TouchableOpacity key={item} style={styles.button} onPress={() => handlePress(item)}>
            <Text style={styles.buttonText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.row}>
        {['0', 'C', '⌫', '+'].map((item) => (
          <TouchableOpacity key={item} style={styles.button} onPress={() => handlePress(item)}>
            <Text style={styles.buttonText}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.row}>
        {['(', ')', '.', '='].map((item) => (
          <TouchableOpacity key={item} style={[styles.button, item === '=' ? styles.equalButton : null]} onPress={() => handlePress(item)}>
            <Text style={[styles.buttonText, item === '=' ? styles.equalText : null]}>{item}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#222',
    padding: 10,
  },
  display: {
    fontSize: 40,
    textAlign: 'right',
    width: '95%',
    backgroundColor: '#333',
    color: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '95%',
    marginVertical: 5,
  },
  button: {
    flex: 1,
    backgroundColor: '#444',
    paddingVertical: 20,
    margin: 5,
    borderRadius: 10,
    alignItems: 'center',
  },
  funcButton: {
    flex: 1,
    backgroundColor: '#555',
    paddingVertical: 15,
    margin: 5,
    borderRadius: 10,
    alignItems: 'center',
  },
  equalButton: {
    backgroundColor: '#f39c12',
  },
  buttonText: {
    fontSize: 26,
    color: '#fff',
    fontWeight: 'bold',
  },
  funcText: {
    fontSize: 22,
    color: '#ddd',
  },
  equalText: {
    color: '#fff',
  },
});


