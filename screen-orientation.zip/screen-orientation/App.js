import React, { useState } from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import * as ScreenOrientation from "expo-screen-orientation";

const Stack = createStackNavigator();

const HomeScreen = ({ navigation }) => {
  const [isLocked, setIsLocked] = useState(false);

  const lockOrientation = async () => {
    if (!isLocked) {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    } else {
      await ScreenOrientation.unlockAsync();
    }
    setIsLocked(!isLocked);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>✨ Welcome Home ✨</Text>
      <Button title="Go to Second Screen" color="#ff69b4" onPress={() => navigation.navigate("SecondScreen")} />
      <Button title={isLocked ? "Unlock Orientation" : "Lock Orientation"} color="#ff69b4" onPress={lockOrientation} />
    </View>
  );
};

const SecondScreen = ({ navigation }) => {
  React.useEffect(() => {
    const changeOrientation = async () => {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
    };
    changeOrientation();

    return () => {
      ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
    };
  }, []);

  return (
    <View style={styles.containerAlt}>
      <Text style={styles.textAlt}>🌸 Second Screen (Landscape) 🌸</Text>
      <Button title="Go Back" color="#ff69b4" onPress={() => navigation.goBack()} />
    </View>
  );
};

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
        <Stack.Screen name="SecondScreen" component={SecondScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffe4e1",
  },
  text: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#d63384",
  },
  containerAlt: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffb6c1",
    transform: [{ rotate: "90deg" }],
  },
  textAlt: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#ffffff",
    textAlign: "center",
  },
});


