import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default function App() {
  const today = new Date();
  const date = today.toDateString(); // Example: "Fri, Mar 01 2025"

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Today's Date: {date}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
});

